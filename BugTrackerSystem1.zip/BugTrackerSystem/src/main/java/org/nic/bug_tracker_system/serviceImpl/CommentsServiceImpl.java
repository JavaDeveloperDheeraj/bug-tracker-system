package org.nic.bug_tracker_system.serviceImpl;

import org.nic.bug_tracker_system.service.CommentsService;

public class CommentsServiceImpl implements CommentsService{

}
