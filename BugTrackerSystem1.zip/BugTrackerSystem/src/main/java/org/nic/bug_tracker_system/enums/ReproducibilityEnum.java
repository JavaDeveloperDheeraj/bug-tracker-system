package org.nic.bug_tracker_system.enums;

public enum ReproducibilityEnum {
	HAVE_NOT_TRIED,
	HAVE_TRIED,
	TRIED_BUT_FAILED

}
