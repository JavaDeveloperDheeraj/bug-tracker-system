package org.nic.bug_tracker_system.enums;

public enum SeverityEnum {
	MINOR,
	URGENT,
	MAJOR
}
