package org.nic.bug_tracker_system.enums;

public enum StatusEnum {
	CREATED,
	OPEN,
	CLOSED
}
