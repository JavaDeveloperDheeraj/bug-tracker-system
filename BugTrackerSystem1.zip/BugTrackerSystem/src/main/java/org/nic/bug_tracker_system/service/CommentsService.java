package org.nic.bug_tracker_system.service;

public interface CommentsService {

}
