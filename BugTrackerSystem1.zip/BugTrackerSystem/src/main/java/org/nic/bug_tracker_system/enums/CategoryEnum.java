package org.nic.bug_tracker_system.enums;

public enum CategoryEnum {
	BUG_BY_END_USERS,
	CHANGE_REQUEST,
	CLARIFICATION,
	ENHANCEMENT,
	GENERAL,
	INTERNAL_BUG,
	NEW_REQUIREMENT

}
