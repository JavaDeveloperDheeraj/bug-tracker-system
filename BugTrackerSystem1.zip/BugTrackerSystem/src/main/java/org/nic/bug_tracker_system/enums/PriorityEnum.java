package org.nic.bug_tracker_system.enums;

public enum PriorityEnum {
	NORMAL,
	URGENT,
	MAJOR

}
