package org.nic.bug_tracker_system.service;

import java.util.List;

public interface SeverityEnumService {
    List<String> getFormattedSeverityEnums();
}
