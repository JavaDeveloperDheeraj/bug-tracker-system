package com.nic.bts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BugTrackerSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
